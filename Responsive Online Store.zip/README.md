
  # Responsive Online Store

  This is a code bundle for Responsive Online Store. The original project is available at https://www.figma.com/design/YJtQknQchTyKfAXXIz8OTU/Responsive-Online-Store.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  