import React from 'react';
import { Card, CardContent, CardFooter } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ShoppingCart, Eye } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export interface Product {
  id: string;
  name: string;
  category: string;
  image: string;
  price: number;
  boxPrice?: number;
  sizes?: string;
  stock?: number;
}

interface ProductCardProps {
  product: Product;
  currency: string;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currency,
  onAddToCart,
  onViewDetails
}) => {
  const formatPrice = (price: number) => {
    const symbol = currency === 'USD' ? '$' : currency === 'ARS' ? '$' : '₲';
    return `${symbol}${price.toLocaleString()}`;
  };

  return (
    <Card className="group h-full backdrop-blur-md bg-background/80 border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20">
      <CardContent className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <ImageWithFallback
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <Button
            variant="secondary"
            size="icon"
            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            onClick={() => onViewDetails(product)}
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="p-4">
          <div className="flex items-start justify-between mb-2">
            <h3 className="font-medium line-clamp-2 flex-1">{product.name}</h3>
            <Badge variant="secondary" className="ml-2 shrink-0">
              {product.category}
            </Badge>
          </div>
          
          <div className="space-y-1">
            <p className="text-lg font-semibold text-primary">
              {formatPrice(product.price)}
            </p>
            {product.boxPrice && (
              <p className="text-sm text-muted-foreground">
                Caja (6u): {formatPrice(product.boxPrice)}
              </p>
            )}
            {product.sizes && (
              <p className="text-sm text-muted-foreground">
                Talles: {product.sizes}
              </p>
            )}
            {product.stock !== undefined && (
              <p className="text-xs text-muted-foreground">
                Stock: {product.stock}
              </p>
            )}
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button 
          onClick={() => onAddToCart(product)}
          className="w-full"
          disabled={product.stock === 0}
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          {product.stock === 0 ? 'Sin Stock' : 'Añadir al Carrito'}
        </Button>
      </CardFooter>
    </Card>
  );
};