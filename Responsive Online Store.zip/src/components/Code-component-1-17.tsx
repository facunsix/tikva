import React from 'react';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { ShoppingCart, User, Sun, Moon, Instagram, Facebook } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface NavbarProps {
  isDarkMode: boolean;
  onThemeToggle: () => void;
  currency: string;
  onCurrencyChange: (currency: string) => void;
  onLoginClick: () => void;
  cartItemsCount: number;
  onCartClick: () => void;
  isLoggedIn: boolean;
  userEmail?: string;
  onLogout: () => void;
  onProfileClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  isDarkMode,
  onThemeToggle,
  currency,
  onCurrencyChange,
  onLoginClick,
  cartItemsCount,
  onCartClick,
  isLoggedIn,
  userEmail,
  onLogout,
  onProfileClick
}) => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <ImageWithFallback
              src="https://i.ibb.co/1JTm1rQk/logo.png"
              alt="Tikvá Logo"
              className="h-10 w-auto"
            />
            <h1 className="text-xl font-bold text-primary">Tikvá</h1>
          </div>

          {/* Centro - Enlaces de navegación */}
          <div className="hidden md:flex items-center space-x-6">
            <a href="#productos" className="hover:text-primary transition-colors">Productos</a>
            <a href="#promociones" className="hover:text-primary transition-colors">Promociones</a>
          </div>

          {/* Derecha - Controles */}
          <div className="flex items-center space-x-4">
            {/* Selector de moneda */}
            <Select value={currency} onValueChange={onCurrencyChange}>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="USD">USD</SelectItem>
                <SelectItem value="ARS">ARS</SelectItem>
                <SelectItem value="PYG">PYG</SelectItem>
              </SelectContent>
            </Select>

            {/* Toggle tema */}
            <div className="flex items-center space-x-2">
              <Sun className="h-4 w-4" />
              <Switch
                checked={isDarkMode}
                onCheckedChange={onThemeToggle}
              />
              <Moon className="h-4 w-4" />
            </div>

            {/* Redes sociales */}
            <div className="hidden md:flex items-center space-x-2">
              <Button variant="ghost" size="icon" asChild>
                <a href="#" target="_blank" rel="noopener noreferrer">
                  <Instagram className="h-4 w-4" />
                </a>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <a href="#" target="_blank" rel="noopener noreferrer">
                  <Facebook className="h-4 w-4" />
                </a>
              </Button>
            </div>

            {/* Usuario/Login */}
            {isLoggedIn ? (
              <div className="flex items-center space-x-2">
                <Button variant="ghost" onClick={onProfileClick} className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span className="hidden md:inline">{userEmail}</span>
                </Button>
                <Button variant="outline" onClick={onLogout}>
                  Salir
                </Button>
              </div>
            ) : (
              <Button onClick={onLoginClick} className="flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>Login</span>
              </Button>
            )}

            {/* Carrito */}
            <Button variant="outline" onClick={onCartClick} className="relative">
              <ShoppingCart className="h-4 w-4" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};